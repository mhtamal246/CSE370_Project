<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

include 'admindb.php';


$result = $conn->query("SELECT id, name FROM student");

$conn->close();
?>

<<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users - BRACu TravelBuddy</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 min-h-screen flex">

<div class="bg-blue-800 text-white w-64 min-h-screen p-6">
    <h2 class="text-2xl font-bold mb-6">Admin Dashboard</h2>
    <nav>
        <ul>
            <li class="mb-4">
                <a href="admin_dashboard.php" class="block py-2 px-4 rounded hover:bg-blue-700">Dashboard</a>
            </li>
            <li class="mb-4">
                <a href="manage_users.php" class="block py-2 px-4 rounded hover:bg-blue-700">Manage Users</a>
            </li>
            <li class="mb-4">
                <a href="admin_logout.php" class="block py-2 px-4 rounded hover:bg-blue-700">Logout</a>
            </li>
        </ul>
    </nav>
</div>


<div class="flex-1 p-10">
    <h1 class="text-3xl font-bold mb-6">Manage Users</h1>
    <div class="bg-white p-6 rounded-lg shadow-lg">
        <h2 class="text-xl font-bold mb-4">User List</h2>
        <ul>
            <?php while ($row = $result->fetch_assoc()): ?>
                <li class="mb-2 flex justify-between items-center">
                    <a href="user_profile.php?id=<?php echo $row['id']; ?>" class="text-blue-500 hover:underline">
                        <?php echo htmlspecialchars($row['name']); ?>
                    </a>
                    <a href="delete_user.php?id=<?php echo $row['id']; ?>" class="text-red-500 hover:underline ml-4">Delete</a>
                </li>
            <?php endwhile; ?>
        </ul>
    </div>
</div>
</body>
</html>